import { ArrowRight, ArrowUpRight, Bookmark, BookmarkCheck, Check, Clock3, ExternalLink, ShieldAlert, Sparkles } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import SiteHeader from "@/components/SiteHeader";
import { trpc } from "@/lib/trpc";

const bookmarksKey = "everyfix-saved-guides";

function BrandMini() {
  return <Link href="/" className="guide-brand"><span className="guide-brand-mark" aria-hidden="true"><Check size={20} /></span>Every<span>Fix</span></Link>;
}

export default function GuidePage({ slug }: { slug: string }) {
  const guideQuery = trpc.guides.bySlug.useQuery({ slug }, { staleTime: 180_000 });
  const catalogQuery = trpc.guides.list.useQuery(undefined, { staleTime: 180_000 });
  const guide = guideQuery.data;
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);
  const categories = catalogQuery.data?.categories ?? [];
  const category = categories.find(item => item.id === guide?.categoryId);
  const relatedGuides = useMemo(() => {
    if (!guide || !catalogQuery.data) return [];
    return guide.relatedGuideIds.map(id => catalogQuery.data.guides.find(item => item.id === id)).filter((item): item is NonNullable<typeof item> => Boolean(item)).slice(0, 3);
  }, [catalogQuery.data, guide]);

  useEffect(() => {
    try {
      const savedIds = JSON.parse(localStorage.getItem(bookmarksKey) ?? "[]") as string[];
      setSaved(savedIds.includes(slug));
    } catch {
      setSaved(false);
    }
  }, [slug]);

  const toggleSaved = () => {
    try {
      const savedIds = JSON.parse(localStorage.getItem(bookmarksKey) ?? "[]") as string[];
      const next = saved ? savedIds.filter(id => id !== slug) : [...new Set([...savedIds, slug])];
      localStorage.setItem(bookmarksKey, JSON.stringify(next));
      setSaved(!saved);
    } catch {
      setSaved(false);
    }
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  };

  if (guideQuery.isLoading) {
    return <main className="guide-loading" aria-live="polite"><span className="loader-dot" /><p>Finding your guide…</p></main>;
  }

  if (guideQuery.isError) {
    return <main className="guide-error"><BrandMini /><div className="guide-error-panel"><span className="empty-symbol"><Sparkles size={22} /></span><h1>This guide isn’t ready to load.</h1><p>Please check your connection and try again.</p><button className="primary-button" onClick={() => void guideQuery.refetch()}>Try again <ArrowRight size={17} /></button><p><Link href="/">Back to all guides</Link></p></div></main>;
  }

  if (!guide) {
    return <main className="guide-error"><BrandMini /><div className="guide-error-panel"><span className="empty-symbol"><Sparkles size={22} /></span><h1>We couldn’t find that guide.</h1><p>It may have moved. Find another practical next step instead.</p><Link href="/" className="primary-button">Browse EveryFix <ArrowRight size={17} /></Link></div></main>;
  }

  return (
    <div className="guide-shell">
      <SiteHeader />
      <main id="main-content" className="guide-main">
        <div className="guide-breadcrumb"><Link href="/">EveryFix</Link><span>/</span>{category?.name ?? "Guide"}</div>
        <article className="guide-article">
          <div className="guide-intro">
            <span className="guide-kicker"><span className="guide-kicker-dot" />{category?.name ?? "Everyday guide"}</span>
            <h1>{guide.title}</h1>
            <p className="guide-summary">{guide.summary}</p>
            <div className="guide-byline"><span><Clock3 size={15} /> {guide.minutes} min read</span><span className="byline-dot">·</span><span>{guide.steps.length} simple steps</span><div className="guide-actions"><button className={`icon-action ${saved ? "is-saved" : ""}`} onClick={toggleSaved} aria-label={saved ? "Remove from saved guides" : "Save this guide"} title={saved ? "Saved to this device" : "Save guide on this device"}>{saved ? <BookmarkCheck size={17} /> : <Bookmark size={17} />}<span>{saved ? "Saved" : "Save"}</span></button><button className="icon-action" onClick={() => void copyLink()} aria-label="Copy link to guide" title="Copy link"><ExternalLink size={16} /><span>{copied ? "Copied" : "Share"}</span></button></div></div>
          </div>

          {guide.safetyNote && <aside className="safety-callout" aria-label="Important safety note"><span className="safety-icon"><ShieldAlert size={20} /></span><div><strong>Before you begin</strong><p>{guide.safetyNote}</p></div></aside>}

          <section className="steps-section" aria-labelledby="steps-title">
            <div className="steps-title-row"><div><span className="section-kicker">Your next steps</span><h2 id="steps-title">Start where you are.</h2></div><span className="steps-count">{guide.steps.length} steps</span></div>
            <ol className="step-list">
              {guide.steps.map((step, index) => <li key={`${index}-${step.title}`} className="guide-step"><span className="step-number">{String(index + 1).padStart(2, "0")}</span><div className="step-copy"><h3>{step.title}</h3><p>{step.body}</p></div></li>)}
            </ol>
          </section>

          {guide.resources.length > 0 && <section className="resources-section" aria-labelledby="resources-title"><span className="section-kicker">Go a little deeper</span><h2 id="resources-title">Helpful resources</h2><div className="resource-list">{guide.resources.map(resource => <a className="resource-card" href={resource.url} target="_blank" rel="noopener noreferrer" key={resource.url}><span className="resource-mark"><ArrowUpRight size={17} /></span><span className="resource-copy"><span>{resource.label}{resource.locale && <small>{resource.locale}</small>}</span><span>{resource.description}</span></span><ExternalLink className="resource-external" size={15} /></a>)}</div></section>}

          {relatedGuides.length > 0 && <section className="related-section" aria-labelledby="related-title"><div className="related-header"><div><span className="section-kicker">A next small step</span><h2 id="related-title">You might also find this useful.</h2></div><Link href="/" className="soft-link">All guides <ArrowRight size={16} /></Link></div><div className="related-list">{relatedGuides.map(item => <Link href={`/guide/${item.id}`} className="related-card" key={item.id}><span className="related-title">{item.title}</span><span className="related-summary">{item.summary}</span><span className="related-meta"><Clock3 size={14} /> {item.minutes} min <ArrowUpRight size={16} /></span></Link>)}</div></section>}
        </article>
      </main>
      <footer className="guide-footer"><BrandMini /><p>General information only. If the situation is urgent, contact local emergency or professional support.</p></footer>
    </div>
  );
}
