import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  BriefcaseBusiness,
  Check,
  Clock3,
  Heart,
  HeartPulse,
  House,
  Laptop,
  Leaf,
  MessagesSquare,
  Search,
  ShieldCheck,
  Sparkles,
  Wallet,
} from "lucide-react";
import { useMemo, useState, type FormEvent } from "react";
import { Link, useLocation } from "wouter";
import SiteHeader, { BrandLink } from "@/components/SiteHeader";
import { trpc } from "@/lib/trpc";
import "./Home.css";

type CategoryId = "home" | "technology" | "money" | "wellbeing" | "work" | "relationships" | "wealth";

function CategoryIcon({ id, size = 22 }: { id: string; size?: number }) {
  const common = { size, strokeWidth: 1.8 };
  switch (id as CategoryId) {
    case "home": return <House {...common} />;
    case "technology": return <Laptop {...common} />;
    case "money": return <Wallet {...common} />;
    case "wellbeing": return <HeartPulse {...common} />;
    case "work": return <BriefcaseBusiness {...common} />;
    case "relationships": return <MessagesSquare {...common} />;
    case "wealth": return <Wallet {...common} />;
    default: return <BookOpen {...common} />;
  }
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [searchText, setSearchText] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [visibleCount, setVisibleCount] = useState(6);
  const catalogQuery = trpc.guides.list.useQuery(undefined, { staleTime: 180_000 });
  const categories = catalogQuery.data?.categories ?? [];
  const guides = catalogQuery.data?.guides ?? [];
  const everydayCategories = categories.filter(category => category.id !== "wealth");
  const everydayGuides = guides.filter(guide => guide.categoryId !== "wealth");

  const filteredGuides = useMemo(() => {
    const term = searchText.trim().toLocaleLowerCase();
    return everydayGuides.filter(guide => {
      const category = categories.find(item => item.id === guide.categoryId)?.name ?? "";
      const matchesCategory = activeCategory === "all" || guide.categoryId === activeCategory;
      const searchable = [guide.title, guide.summary, category, ...guide.tags].join(" ").toLocaleLowerCase();
      return matchesCategory && (!term || searchable.includes(term));
    });
  }, [activeCategory, categories, everydayGuides, searchText]);

  const featuredGuides = everydayGuides.filter(guide => guide.featured).slice(0, 3);
  const olderAdultTechGuides = guides.filter(guide => guide.categoryId === "technology" && guide.tags.includes("older adults")).slice(0, 3);
  const categoryCounts = useMemo(
    () => Object.fromEntries(categories.map(category => [category.id, guides.filter(guide => guide.categoryId === category.id).length])),
    [categories, guides],
  );

  const handleSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setActiveCategory("all");
    setVisibleCount(6);
    document.getElementById("explore")?.scrollIntoView({ behavior: "auto", block: "start" });
  };

  const resetFilters = () => {
    setSearchText("");
    setActiveCategory("all");
    setVisibleCount(6);
  };

  const askAboutSearch = () => {
    const problem = searchText.trim().slice(0, 800);
    if (problem.length >= 10) {
      setLocation("/ask", { state: { everyfixProblem: problem } });
    }
  };

  return (
    <div className="site-shell">
      <SiteHeader />

      <main id="main-content">
        <section className="hero-section">
          <div className="hero-inner">
            <div className="hero-copy">
              <div className="eyebrow"><span className="eyebrow-spark"><Sparkles size={13} /></span> A little help, right when you need it</div>
              <h1>Small problems.<br /><span>Clear next steps.</span></h1>
              <p className="hero-description">Everyday life gets easier when you know where to begin. Find thoughtful, practical guides for the things that trip us all up.</p>
              <form className="hero-search" onSubmit={handleSearch} role="search">
                <Search size={20} aria-hidden="true" />
                <label className="sr-only" htmlFor="guide-search">Search everyday problems</label>
                <input id="guide-search" name="q" type="search" value={searchText} onChange={event => { setSearchText(event.target.value); setVisibleCount(6); }} placeholder="What would you like help with?" autoComplete="off" />
                <button type="submit" aria-label="Search guides"><ArrowRight size={19} /></button>
              </form>
              <div className="hero-trust-line"><ShieldCheck size={16} /><span>Thoughtful guidance. No judgment. Safety first.</span></div>
            </div>
            <div className="hero-art-wrap" aria-hidden="true">
              <div className="hero-art-halo" />
              <div className="hero-sticker hero-sticker-top"><span className="sticker-icon sticker-icon-teal"><Check size={14} /></span><span>One step at a time</span></div>
              <img className="hero-art" src="/manus-storage/async-images/e03gFhqEVlEI7P4dPPj8UJ/image-1.webp" alt="" fetchPriority="high" />
              <div className="hero-sticker hero-sticker-bottom"><span className="sticker-icon sticker-icon-lilac"><Heart size={14} /></span><span>Made for real life</span></div>
              <span className="hero-leaf hero-leaf-one"><Leaf size={30} /></span>
              <span className="hero-leaf hero-leaf-two"><Sparkles size={19} /></span>
            </div>
          </div>
          <div className="hero-bottom-rule"><span /><span /><span /></div>
        </section>

        <section className="topic-section content-width" id="topics" aria-labelledby="topics-title">
          <div className="section-heading section-heading-topics">
            <div>
              <span className="section-kicker">A good place to start</span>
              <h2 id="topics-title">What’s on your mind?</h2>
            </div>
            <p>Pick a corner of life. We’ll help with the next small step.</p>
          </div>
          {catalogQuery.isError ? (
            <div className="notice-panel" role="status"><p>We couldn’t load the topics just now. Your guides are still here—try again in a moment.</p><button className="text-button" onClick={() => void catalogQuery.refetch()}>Try again <ArrowRight size={16} /></button></div>
          ) : catalogQuery.isLoading ? (
            <div className="category-skeleton" aria-label="Loading topics"><span /><span /><span /><span /><span /><span /></div>
          ) : (
            <div className="category-list">
              {everydayCategories.map(category => (
                <button key={category.id} className={`category-card category-${category.id} ${activeCategory === category.id ? "is-selected" : ""}`} onClick={() => { setActiveCategory(category.id); setVisibleCount(6); document.getElementById("explore")?.scrollIntoView({ behavior: "auto", block: "start" }); }} aria-pressed={activeCategory === category.id}>
                  <span className="category-icon"><CategoryIcon id={category.id} /></span>
                  <span className="category-copy"><span className="category-title">{category.name}</span><span className="category-description">{category.description}</span></span>
                  <span className="category-count">{categoryCounts[category.id] ?? 0}</span>
                  <ArrowUpRight className="category-arrow" size={16} aria-hidden="true" />
                </button>
              ))}
            </div>
          )}
        </section>

        <section className="tech-help-section" id="tech-help" aria-labelledby="tech-help-title">
          <div className="content-width">
            <div className="tech-help-heading"><div><span className="section-kicker">Patient technology help</span><h2 id="tech-help-title">Tech that feels simpler, at any age.</h2><p>Plain-language steps for phones, Wi-Fi, calls, and staying safe online. Go one step at a time—there is no rush.</p></div><Link className="soft-link" href="/ask">Ask about your device <ArrowRight size={16} /></Link></div>
            {catalogQuery.isLoading ? <p role="status" aria-live="polite">Loading friendly tech guides…</p> : (
              <div className="tech-help-grid">
                {olderAdultTechGuides.map(guide => <Link className="tech-help-card" href={`/guide/${guide.id}`} key={guide.id}><span className="tech-help-label">A simple tech guide</span><strong>{guide.title}</strong><span>{guide.summary}</span><small>{guide.minutes} min read <ArrowUpRight size={15} aria-hidden="true" /></small></Link>)}
                {olderAdultTechGuides.length === 0 && <p>New patient, plain-language tech guides are on their way.</p>}
              </div>
            )}
          </div>
        </section>

        <section className="featured-section" id="featured" aria-labelledby="featured-title">
          <div className="content-width">
            <div className="section-heading">
              <div>
                <span className="section-kicker">A few reader favorites</span>
                <h2 id="featured-title">A good fix, in a few minutes.</h2>
              </div>
              <a className="soft-link" href="#explore">See every guide <ArrowRight size={16} /></a>
            </div>
            {catalogQuery.isLoading ? (
              <div className="featured-grid" aria-label="Loading popular guides"><div className="guide-skeleton" /><div className="guide-skeleton" /><div className="guide-skeleton" /></div>
            ) : (
              <div className="featured-grid">
                {featuredGuides.map((guide, index) => {
                  const category = categories.find(item => item.id === guide.categoryId);
                  return (
                    <Link className={`featured-card featured-card-${index + 1}`} href={`/guide/${guide.id}`} key={guide.id}>
                      <span className="featured-card-top"><span className="featured-icon"><CategoryIcon id={guide.categoryId} size={19} /></span><span className="mini-arrow"><ArrowUpRight size={18} /></span></span>
                      <span className="featured-category">{category?.name ?? "Everyday life"}</span>
                      <span className="featured-title">{guide.title}</span>
                      <span className="featured-summary">{guide.summary}</span>
                      <span className="card-meta"><Clock3 size={14} /> {guide.minutes} min read <span className="card-meta-dot">·</span> Simple steps</span>
                    </Link>
                  );
                })}
                {featuredGuides.length === 0 && !catalogQuery.isLoading && <p className="muted-note">New popular guides are on their way.</p>}
              </div>
            )}
          </div>
        </section>

        <section className="browse-section content-width" id="explore" aria-labelledby="explore-title">
          <div className="section-heading browse-heading">
            <div>
              <span className="section-kicker">Find your next step</span>
              <h2 id="explore-title">Small snags, meet small solutions.</h2>
            </div>
            <p>Clear, kind, doable advice for the everyday stuff.</p>
          </div>
          <div className="browse-toolbar">
            <div className="filter-pills" role="group" aria-label="Filter guides by topic">
              <button className={`filter-pill ${activeCategory === "all" ? "active" : ""}`} onClick={() => setActiveCategory("all")} aria-pressed={activeCategory === "all"}>All everyday guides <span>{everydayGuides.length}</span></button>
              {everydayCategories.map(category => <button key={category.id} className={`filter-pill ${activeCategory === category.id ? "active" : ""}`} onClick={() => setActiveCategory(category.id)} aria-pressed={activeCategory === category.id}>{category.name}<span>{categoryCounts[category.id] ?? 0}</span></button>)}
            </div>
            <div className="results-count" aria-live="polite">{searchText || activeCategory !== "all" ? `${filteredGuides.length} ${filteredGuides.length === 1 ? "guide" : "guides"} found` : `${everydayGuides.length} practical guides`}</div>
          </div>
          {searchText.trim() && <p className="search-status">Showing results for <strong>“{searchText.trim()}”</strong> <button onClick={() => setSearchText("")}>Clear search</button></p>}
          {catalogQuery.isError ? (
            <div className="empty-state" role="status"><span className="empty-symbol"><BookOpen size={25} /></span><h3>We couldn’t get the guides just now.</h3><p>Please try again. Your topics and search will be ready when content loads.</p><button className="primary-button" onClick={() => void catalogQuery.refetch()}>Try again <ArrowRight size={17} /></button></div>
          ) : filteredGuides.length === 0 && !catalogQuery.isLoading ? (
            <div className="empty-state" role="status"><span className="empty-symbol"><Search size={24} /></span><h3>No guides found just yet.</h3><p>Try a different search, clear your filters, or browse another topic.</p>{searchText.trim().length >= 10 && <div className="no-match-ai"><div><span className="no-match-ai-kicker"><Sparkles size={14} aria-hidden="true" /> A guide doesn’t cover it yet?</span><p>Ask EveryFix AI for practical next steps about <strong>“{searchText.trim()}”</strong>.</p></div><button className="primary-button" type="button" onClick={askAboutSearch}>Ask EveryFix AI <ArrowRight size={17} aria-hidden="true" /></button></div>}<button className="empty-secondary-button" onClick={resetFilters}>Show all guides <ArrowRight size={17} /></button></div>
          ) : (
            <>
              <div className="guide-list">
                {filteredGuides.slice(0, visibleCount).map(guide => {
                  const category = categories.find(item => item.id === guide.categoryId);
                  return (
                    <Link href={`/guide/${guide.id}`} className="guide-card" key={guide.id}>
                      <span className={`guide-card-icon category-${guide.categoryId}`}><CategoryIcon id={guide.categoryId} size={22} /></span>
                      <span className="guide-card-main"><span className="guide-card-category">{category?.name ?? "Guide"}</span><span className="guide-card-title">{guide.title}</span><span className="guide-card-summary">{guide.summary}</span></span>
                      <span className="guide-card-meta"><span><Clock3 size={14} /> {guide.minutes} min</span><ArrowUpRight className="guide-card-arrow" size={19} /></span>
                    </Link>
                  );
                })}
              </div>
              {filteredGuides.length > visibleCount && <button className="load-more" onClick={() => setVisibleCount(current => current + 6)}>Show more guides <ArrowRight size={16} /></button>}
            </>
          )}
        </section>

        <section className="wealth-invitation content-width" aria-labelledby="wealth-invitation-title">
          <span className="wealth-invitation-icon"><Wallet size={22} aria-hidden="true" /></span>
          <div><span className="section-kicker">A different kind of guide</span><h2 id="wealth-invitation-title">A separate space for money and wealth.</h2><p>Explore careful, practical financial education—kept distinct from everyday fixes, with risk notes and trusted starting points.</p></div>
          <Link href="/wealth" className="wealth-invitation-link">Visit the Wealth section <ArrowRight size={17} /></Link>
        </section>

        <section className="promise-section" id="about">
          <div className="promise-inner content-width">
            <div className="promise-icon"><HeartPulse size={25} /></div>
            <div className="promise-copy"><span className="section-kicker">A more human kind of help</span><h2>Useful, never overwhelming.</h2><p>Every guide breaks one problem into manageable steps. When the stakes are higher, we’ll say so—and point you toward the right local or professional support.</p></div>
            <div className="promise-points"><div><Check size={16} /> Practical, plain-language steps</div><div><Check size={16} /> Safety context where it matters</div><div><Check size={16} /> Trusted resources to go deeper</div></div>
          </div>
        </section>

        <section className="closing-section content-width">
          <span className="closing-flower" aria-hidden="true"><Sparkles size={23} /></span>
          <h2>One small step can change the whole day.</h2>
          <p>Start with the thing that’s on your mind. We’ll go from there.</p>
          <a href="#explore" className="primary-button">Find your next step <ArrowRight size={17} /></a>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-inner content-width">
          <BrandLink compact />
          <p>Kind, practical guidance for life as it happens.</p>
          <span>For general information only. When a situation is urgent, contact local emergency or professional support.</span>
        </div>
      </footer>
    </div>
  );
}
