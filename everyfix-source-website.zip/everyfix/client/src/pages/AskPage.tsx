import { ArrowLeft, ArrowRight, ArrowUpRight, Sparkles } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { Link } from "wouter";
import SiteHeader, { BrandLink } from "@/components/SiteHeader";
import { trpc } from "@/lib/trpc";

const examples = [
  "My phone keeps saying storage is full. Where can I start?",
  "How can I make a simple plan for a busy week at home?",
  "I got an unexpected message about a delivery. What should I do?",
];

export default function AskPage() {
  const [problem, setProblem] = useState(() => {
    const state = window.history.state as { everyfixProblem?: unknown } | null;
    return typeof state?.everyfixProblem === "string" ? state.everyfixProblem.slice(0, 800) : "";
  });
  const [serverError, setServerError] = useState("");
  const solver = trpc.ai.ask.useMutation({
    onSuccess: () => setServerError(""),
    onError: error => setServerError(error.message || "The AI guide is unavailable right now. Please try again."),
  });

  useEffect(() => {
    const state = window.history.state as { everyfixProblem?: unknown } | null;
    const incomingProblem = typeof state?.everyfixProblem === "string" ? state.everyfixProblem.trim().slice(0, 800) : "";
    if (!incomingProblem) return;

    // Consume the one-time prompt so it is neither exposed in the URL nor kept in history state.
    window.history.replaceState(null, "", window.location.href);
    setProblem(incomingProblem);
    if (incomingProblem.length < 10) return;

    solver.mutate({ problem: incomingProblem });
  }, [solver.mutate]);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (problem.trim().length < 10) {
      setServerError("Please describe the problem in at least 10 characters.");
      return;
    }
    setServerError("");
    solver.reset();
    solver.mutate({ problem: problem.trim() });
  };

  const result = solver.data;

  return (
    <div className="site-shell ask-page">
      <SiteHeader />
      <main id="main-content">
        <section className="ask-hero" aria-labelledby="ask-title">
          <div className="ask-hero-inner">
            <span className="ask-kicker"><Sparkles size={14} aria-hidden="true" /> A thoughtful starting point</span>
            <h1 id="ask-title">Stuck on something not in the guide list?</h1>
            <p>Describe an everyday problem in your preferred language. EveryFix AI can suggest a few small, practical next steps, answer in that language, and point you to a related guide when one fits.</p>
          </div>
        </section>

        <section className="ask-panel" aria-label="Describe a problem for the AI guide">
          <form className="ask-form" onSubmit={submit} aria-busy={solver.isPending}>
            <label htmlFor="ask-problem">What would you like help with?</label>
            <textarea id="ask-problem" name="problem" value={problem} maxLength={800} dir="auto" onChange={event => { setProblem(event.target.value); setServerError(""); solver.reset(); }} placeholder="For example: I keep missing reminders on my phone. What are a few simple things I can try?" aria-describedby="ask-privacy ask-limit" required minLength={10} />
            <div className="ask-form-help"><span id="ask-privacy">You can write in your preferred language; support varies by language and dialect. Your question is sent to the AI service to generate an answer; this site does not save it as chat history. Please leave out names, passwords, account numbers, and other identifying details.</span><span id="ask-limit">{problem.length}/800 characters</span></div>
            <button className="primary-button" type="submit" disabled={solver.isPending || problem.trim().length < 10}>
              {solver.isPending ? <><span className="ask-spinner" aria-hidden="true" /> Thinking through next steps…</> : <>Find a helpful starting point <ArrowRight size={17} /></>}
            </button>
            {serverError && <p className="ask-error" role="alert">{serverError}</p>}
            <div className="ask-suggestions" aria-label="Example questions">
              {examples.map(example => <button type="button" key={example} onClick={() => { setProblem(example); setServerError(""); solver.reset(); }}>{example}</button>)}
            </div>
          </form>

          {result && (
            <section className="ask-result" aria-live="polite" aria-labelledby="solution-title">
              <span className="ask-kicker">A possible next step</span>
              <h2 id="solution-title" dir="auto">{result.answer.title}</h2>
              <p className="ask-result-summary" dir="auto">{result.answer.summary}</p>
              <ol dir="auto">{result.answer.steps.map((step, index) => <li key={`${index}-${step.title}`} dir="auto"><strong>{step.title}</strong>{step.body}</li>)}</ol>
              <aside className="ask-safety" dir="auto">{result.answer.safetyNote}</aside>
              {result.relatedGuides.length > 0 && <div className="ask-related"><h3>Related EveryFix guides</h3>{result.relatedGuides.map(guide => <Link href={`/guide/${guide.id}`} key={guide.id}>{guide.title} <ArrowUpRight size={15} aria-hidden="true" /><span className="sr-only"> (opens a guide)</span></Link>)}</div>}
              <p className="ask-privacy-note">AI answers may be wrong or out of date. Verify important, local, medical, legal, and financial details with an appropriate trusted source. This is general information—not professional advice.</p>
            </section>
          )}
        </section>
      </main>
      <footer className="guide-footer"><BrandLink compact /><p>For urgent danger, contact your local emergency or crisis support. <Link href="/"><ArrowLeft size={13} /> Return to all everyday guides</Link></p></footer>
    </div>
  );
}
