import { ArrowRight, ArrowUpRight, CircleDollarSign, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import SiteHeader, { BrandLink } from "@/components/SiteHeader";
import { trpc } from "@/lib/trpc";

export default function WealthPage() {
  const catalog = trpc.guides.list.useQuery(undefined, { staleTime: 180_000 });
  const wealthGuides = (catalog.data?.guides ?? []).filter(guide => guide.categoryId === "wealth");

  return (
    <div className="site-shell wealth-page">
      <SiteHeader />
      <main id="main-content">
        <section className="wealth-hero" aria-labelledby="wealth-title">
          <div className="wealth-hero-inner">
            <span className="wealth-kicker"><CircleDollarSign size={16} /> Your separate money-learning space</span>
            <h1 id="wealth-title">Wealth, built one informed step at a time.</h1>
            <p>Plain-language ways to understand saving, money habits, and investing basics—without quick-rich promises or pressure to choose a product.</p>
            <div className="wealth-safe-note" role="note"><ShieldCheck size={22} aria-hidden="true" /><div><strong>Education, not personal financial advice.</strong> Investments can lose value; nothing here promises a return or tells you what to buy. Tax, account, debt, and consumer rules vary by location.</div></div>
          </div>
        </section>

        <section className="wealth-guide-section" aria-labelledby="wealth-guides-title">
          <h2 id="wealth-guides-title">Start with what you want to understand</h2>
          <p className="wealth-guide-intro">Take one topic at a time. Each guide links to independent educational resources and names the limits of general information.</p>
          {catalog.isError ? (
            <div className="notice-panel" role="status"><p>The guides could not load right now.</p><button className="text-button" type="button" onClick={() => void catalog.refetch()}>Try again <ArrowRight size={16} /></button></div>
          ) : catalog.isLoading ? (
            <p role="status" aria-live="polite">Loading Wealth guides…</p>
          ) : wealthGuides.length === 0 ? (
            <div className="notice-panel" role="status"><p>New Wealth guides are being prepared.</p><Link className="text-button" href="/">Browse everyday guides <ArrowRight size={16} /></Link></div>
          ) : (
            <div className="wealth-guide-list">
              {wealthGuides.map(guide => (
                <Link className="wealth-guide-card" href={`/guide/${guide.id}`} key={guide.id}>
                  <strong>{guide.title}</strong>
                  <span>{guide.summary}</span>
                  <small>{guide.minutes} min read <ArrowUpRight size={15} aria-hidden="true" /></small>
                </Link>
              ))}
            </div>
          )}
          <div className="wealth-bottom-note"><strong>Take time before acting.</strong> Pause around guaranteed returns, “secret” systems, unusual urgency, or requests to send money to someone you do not know. If a financial choice affects your situation, seek qualified, local advice.</div>
        </section>
      </main>
      <footer className="wealth-footer"><BrandLink compact /><p>For general information only. Sources marked for the United States are specific to U.S. consumers.</p></footer>
    </div>
  );
}
