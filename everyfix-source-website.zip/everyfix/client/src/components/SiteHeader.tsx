import { ArrowUpRight, Check } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import "./SiteHeader.css";

const textPreferenceKey = "everyfix-larger-text";

function getInitialTextSize() {
  try {
    return typeof window !== "undefined" && window.localStorage.getItem(textPreferenceKey) === "large";
  } catch {
    return false;
  }
}

export function BrandLink({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className={`brand${compact ? " brand-compact" : ""}`} aria-label="EveryFix home">
      <span className="brand-mark" aria-hidden="true"><svg viewBox="0 0 36 36" fill="none"><path d="M11 5.5h14a5.5 5.5 0 0 1 5.5 5.5v14a5.5 5.5 0 0 1-5.5 5.5h-14A5.5 5.5 0 0 1 5.5 25V11A5.5 5.5 0 0 1 11 5.5Z" stroke="currentColor" strokeWidth="2.2"/><path d="m11.5 18.2 4.2 4.1L25 12.7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/><path d="M27.5 7.3v5M25 9.8h5" stroke="#45A895" strokeWidth="1.8" strokeLinecap="round"/></svg></span>
      <span className="brand-name">Every<span>Fix</span></span>
    </Link>
  );
}

function TextSizeButton() {
  const [large, setLarge] = useState(getInitialTextSize);

  useEffect(() => {
    document.documentElement.dataset.textScale = large ? "large" : "standard";
  }, [large]);

  const toggle = () => {
    const next = !large;
    setLarge(next);
    try { window.localStorage.setItem(textPreferenceKey, next ? "large" : "standard"); } catch { /* The control still works for this visit. */ }
  };

  return <button type="button" className="text-size-button" onClick={toggle} aria-pressed={large} aria-label={large ? "Use standard text size" : "Make the website text larger"} title={large ? "Use standard text size" : "Make the website text larger"}><span className="text-size-glyph" aria-hidden="true">Aa</span><span>{large ? "Standard text" : "Larger text"}</span></button>;
}

export default function SiteHeader() {
  return (
    <>
      <a className="skip-link" href="#main-content">Skip to content</a>
      <header className="site-header">
        <div className="header-inner">
          <BrandLink />
          <nav className="main-nav" aria-label="Main navigation">
            <Link href="/#explore">Everyday fixes</Link>
            <Link href="/#tech-help">Tech help</Link>
            <Link href="/wealth">Wealth</Link>
          </nav>
          <div className="header-actions">
            <TextSizeButton />
            <Link className="header-cta" href="/ask">Ask EveryFix <ArrowUpRight size={16} /></Link>
          </div>
        </div>
      </header>
    </>
  );
}
