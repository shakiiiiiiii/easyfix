CREATE TABLE `guide_categories` (
	`id` varchar(48) NOT NULL,
	`name` varchar(120) NOT NULL,
	`description` varchar(240) NOT NULL,
	`sort_order` int NOT NULL DEFAULT 0,
	CONSTRAINT `guide_categories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guides` (
	`id` varchar(96) NOT NULL,
	`category_id` varchar(48) NOT NULL,
	`title` varchar(220) NOT NULL,
	`summary` text NOT NULL,
	`tags` json NOT NULL,
	`minutes` int NOT NULL DEFAULT 4,
	`featured` int NOT NULL DEFAULT 0,
	`steps` json NOT NULL,
	`safety_note` text,
	`resources` json NOT NULL,
	`related_guide_ids` json NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `guides_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `guides` ADD CONSTRAINT `guides_category_id_guide_categories_id_fk` FOREIGN KEY (`category_id`) REFERENCES `guide_categories`(`id`) ON DELETE no action ON UPDATE no action;