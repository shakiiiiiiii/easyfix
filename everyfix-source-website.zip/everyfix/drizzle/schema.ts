import { int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/** Core user table backing the optional auth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export interface GuideStep {
  title: string;
  body: string;
}

export interface GuideResource {
  label: string;
  url: string;
  description: string;
  locale?: string;
}

export const guideCategories = mysqlTable("guide_categories", {
  id: varchar("id", { length: 48 }).primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  description: varchar("description", { length: 240 }).notNull(),
  sortOrder: int("sort_order").notNull().default(0),
});

export const guides = mysqlTable("guides", {
  id: varchar("id", { length: 96 }).primaryKey(),
  categoryId: varchar("category_id", { length: 48 }).notNull().references(() => guideCategories.id),
  title: varchar("title", { length: 220 }).notNull(),
  summary: text("summary").notNull(),
  tags: json("tags").$type<string[]>().notNull(),
  minutes: int("minutes").notNull().default(4),
  featured: int("featured").notNull().default(0),
  steps: json("steps").$type<GuideStep[]>().notNull(),
  safetyNote: text("safety_note"),
  resources: json("resources").$type<GuideResource[]>().notNull(),
  relatedGuideIds: json("related_guide_ids").$type<string[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type GuideCategory = typeof guideCategories.$inferSelect;
export type Guide = typeof guides.$inferSelect;
