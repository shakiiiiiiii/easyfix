# EveryFix research notes — Wealth and tech made simpler

This note preserves source details used for the Wealth area and older-adult-friendly tech guides. It is editorial context only, not financial or device-specific professional advice.

## Wealth and money education

| Source | Verified context | Planned use |
| --- | --- | --- |
| [SEC Investor.gov — Introduction to Investing](https://www.investor.gov/introduction-investing) | Covers saving vs. investing, short-term savings, compounding, investment risk, time horizon, asset allocation, diversification, long-term investing, and avoiding fraud. It says investments involve risk and may lose value. The site contains U.S.-specific account examples and historical return assumptions; EveryFix will avoid carrying over market-return forecasts or account/tax rules as universal advice. | Link from general education about wealth-building, saving/investing basics, risk, and diversification; clearly distinguish general education from personalized advice. |
| [Consumer Financial Protection Bureau — An essential guide to building an emergency fund](https://www.consumerfinance.gov/an-essential-guide-to-building-an-emergency-fund/) | Suggests selecting a goal and a practical saving routine suited to one's circumstances; even small contributions can help. Automatic transfers require checking balances to avoid overdraft fees. Source is U.S. consumer guidance. | Support a flexible, non-prescriptive starter emergency-savings guide; avoid one-size-fits-all dollar targets. |
| [Federal Trade Commission — Investment Scams](https://consumer.ftc.gov/articles/investment-scams) | Red flags include guaranteed or high returns, low/no risk claims, secret systems, pressure to act quickly, and scant details. Recommends independent verification and reporting through U.S. agencies. | Support an investment-scam prevention guide and avoid implying that a promised return is safe; label U.S.-only reporting links. |
| [SEC Investor.gov — Resources for Investors](https://www.sec.gov/resources-investors) | Provides official investor-education materials and investor-alert resources. | Additional cross-link for general research and fraud awareness. |

**Editorial guardrail:** Wealth pages are educational only; no asset, fund, account, loan, or transaction recommendation; no promised results; no projected returns. Product/tax rules vary by country. Encourage qualified local advice for personal decisions.

## Technology help that respects older adults

| Source | Verified context | Planned use |
| --- | --- | --- |
| [Apple — Personalize Accessibility, Health, and Safety features to empower older adults](https://support.apple.com/en-us/126977) | Apple describes settings for larger/bolder text, contrast, magnification/Zoom, reduced motion, speech/reading support, hearing/communication, focus, and personal preferences. Menu availability varies by OS and device. | Link from step-by-step accessibility guides; note that menu names may vary and settings can be adjusted back. |
| [Google Android Accessibility Help — Change text & display settings](https://support.google.com/accessibility/android/answer/11183305?hl=en) | Official Android instructions cover opening Settings and changing font/display sizing; device version and manufacturer affect labels and routes. | Android link in the large-text guide; start with Settings search to reduce brittle menu paths. |
| [Google Android Accessibility Help — Magnification](https://support.google.com/accessibility/android/answer/6006949?hl=en) | Official guidance for Android screen magnification, accessible via device settings. | Optional further reading for magnification without requiring changes to unrelated settings. |
| [FTC — Addressing Scams Affecting Older Adults](https://consumer.ftc.gov/features/addressing-scams-affecting-older-adults) | Describes scam contact across phone, text, email, social media, websites, and multiple payment methods; linked resource hub relates specifically to U.S. consumers. | Inform a calmly worded scam guide; emphasize pausing, not sharing access codes, ending unexpected remote-control sessions, and using an official contact channel. |
| [CISA — Cybersecurity Awareness Program: Older American Resources (archived)](https://www.cisa.gov/resources-tools/resources/cisa-cybersecurity-awareness-program-older-american-resources) | CISA labels this page archived; its resource revision date is November 29, 2021. | Not used as a live guide citation; current FTC resources are used instead. |

**Editorial guardrail:** Use respectful language such as “older adults” or “at any age.” Give one step at a time; do not assume device model, skill level, or family setup. Never ask for passwords, one-time verification codes, remote access, or payment. Encourage using the manufacturer's help route for device-specific menus.


## Additional source checks for the new guide records

| Source | Verified context | Planned use |
| --- | --- | --- |
| [FTC — How To Spot, Avoid, and Report Tech Support Scams](https://consumer.ftc.gov/articles/how-spot-avoid-and-report-tech-support-scams) | Fake alerts may show a warning and phone number; scammers may request remote access or money. Genuine companies do not send unexpected warnings that ask people to call a number. If a user paid or shared access, the FTC points to next steps; its reporting channel is U.S.-specific. | Support the pop-up guide’s pause/no-call/no-remote-control steps. Avoid claiming every warning is harmless; direct people who paid or shared access to a bank and the real provider.
| [American Red Cross — Power Outage Safety](https://www.redcross.org/get-help/how-to-prepare-for-emergencies/types-of-emergencies/power-outage.html) | Recommends flashlights rather than candles, keeping refrigerator/freezer doors closed, considering powered medical needs, and using generators/fuel-burning equipment only outside and away from openings. It advises following food-temperature and medical-provider guidance. | Support the power-outage checklist. The guide intentionally avoids using a one-size-fits-all food-safety or medical rule and points to the source for full instructions.
| [USDA MyPlate](https://www.myplate.gov/) | The prior deep Kitchen URL now presented the U.S. Dietary Guidelines landing message, not a dedicated weekly-meal planner. The root is the current general government nutrition resource. | Treat as optional general nutrition education, not as a meal-planning tool, prescription, or clinical recommendation; the guide tells readers to follow their own dietary and food-safety advice.
| [Google Android Accessibility overview](https://support.google.com/accessibility/android/answer/6006564?hl=en) | Covers Android display/font-size settings, magnification, TalkBack, voice access, screen-reader and other accessibility features. Device/OS availability varies. | Link from simple phone-use guides as further reading; do not imply that every feature exists on every device.

A follow-up check also verified the [Android Change Text & Display settings page](https://support.google.com/accessibility/android/answer/11183305?hl=en): Settings search for “Font size” or “Display size” can find reversible sliders, and the instructions note that some steps/features depend on OS version or do not affect every app.


### Source-maintenance note

A final check found the CISA older-American resource page is explicitly **archived** (revision dated 2021). It was not kept as the primary citation for the new guides. The current FTC older-adult resource is used instead, and the tech-support guide separately cites the current FTC article that names fake browser warnings, unsolicited remote access, and pressure to pay. The U.S.-specific source labels remain visible in guide cards.
