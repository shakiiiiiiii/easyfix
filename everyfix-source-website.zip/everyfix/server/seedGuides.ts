import mysql from "mysql2/promise";
import { drizzle } from "drizzle-orm/mysql2";
import { eq } from "drizzle-orm";
import { guideCategories, guides } from "../drizzle/schema";
import { seedCategories, seedGuides } from "./guideSeeds";
import { expansionCategories, expansionGuides } from "./guideSeedsExpansion";

async function seed() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required to seed EveryFix guide content.");
  }

  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  const db = drizzle(connection);
  let categoriesAdded = 0;
  let guidesAdded = 0;

  try {
    for (const category of [...seedCategories, ...expansionCategories]) {
      const existing = await db.select({ id: guideCategories.id }).from(guideCategories).where(eq(guideCategories.id, category.id)).limit(1);
      if (existing.length === 0) {
        await db.insert(guideCategories).values(category);
        categoriesAdded += 1;
      }
    }

    for (const guide of [...seedGuides, ...expansionGuides]) {
      const existing = await db.select({ id: guides.id }).from(guides).where(eq(guides.id, guide.id)).limit(1);
      if (existing.length === 0) {
        await db.insert(guides).values({ ...guide, featured: guide.featured ? 1 : 0 });
        guidesAdded += 1;
      }
    }

    console.log(`EveryFix content ready: ${categoriesAdded} new categories, ${guidesAdded} new guides.`);
  } finally {
    await connection.end();
  }
}

seed().catch(error => {
  console.error("EveryFix guide seed failed:", error);
  process.exitCode = 1;
});
