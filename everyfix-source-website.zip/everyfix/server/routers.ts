import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import * as db from "./db";
import { generateEveryFixSolution } from "./aiSolutions";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  guides: router({
    list: publicProcedure.query(() => db.getGuideCatalog()),
    bySlug: publicProcedure
      .input(z.object({ slug: z.string().min(1).max(96) }))
      .query(({ input }) => db.getGuideBySlug(input.slug)),
  }),
  ai: router({
    ask: publicProcedure
      .input(z.object({ problem: z.string().trim().min(10).max(800) }))
      .mutation(async ({ input }) => {
        try {
          return await generateEveryFixSolution(input.problem);
        } catch {
          console.warn("[EveryFix AI] A solution could not be generated; request text was not logged or saved.");
          throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "The AI guide is temporarily unavailable. Your question was not saved; try again later or browse the guides." });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
