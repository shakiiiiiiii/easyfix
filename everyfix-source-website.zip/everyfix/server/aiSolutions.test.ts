import { beforeEach, describe, expect, it, vi } from "vitest";

const { invokeLLMMock, listLLMModelsMock, getGuideCatalogMock } = vi.hoisted(() => ({
  invokeLLMMock: vi.fn(),
  listLLMModelsMock: vi.fn(),
  getGuideCatalogMock: vi.fn(),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: invokeLLMMock,
  listLLMModels: listLLMModelsMock,
}));

vi.mock("./db", () => ({ getGuideCatalog: getGuideCatalogMock }));

import { generateEveryFixSolution } from "./aiSolutions";

type LocalizedAnswer = {
  title: string;
  summary: string;
  steps: Array<{ title: string; body: string }>;
  safetyNote: string;
};

function answerInLanguage(language: "es" | "ar" | "fr" | "sq"): LocalizedAnswer {
  if (language === "es") {
    return {
      title: "Quitar una mancha de café",
      summary: "Actúa pronto y trata la mancha con cuidado antes de lavar la prenda.",
      steps: [
        { title: "Retira el exceso", body: "Presiona suavemente con un paño limpio; no frotes la tela." },
        { title: "Enjuaga la mancha", body: "Usa agua fría desde la parte posterior de la tela." },
      ],
      safetyNote: "Comprueba la etiqueta de cuidado y prueba primero cualquier producto en una zona escondida.",
    };
  }

  if (language === "ar") return {
    title: "إزالة بقعة القهوة",
    summary: "عالج البقعة بهدوء وبسرعة قبل غسل قطعة الملابس.",
    steps: [
      { title: "أزل السائل الزائد", body: "اضغط بقطعة قماش نظيفة برفق ولا تفرك القماش." },
      { title: "اشطف البقعة", body: "استخدم ماءً بارداً من الجهة الخلفية للقماش." },
    ],
    safetyNote: "تحقق من ملصق العناية وجرب أي منظف على جزء مخفي أولاً.",
  };

  if (language === "fr") return {
    title: "Enlever une tache de café",
    summary: "Agissez rapidement et traitez la tache avant de laver le vêtement.",
    steps: [
      { title: "Retirez l'excédent", body: "Tamponnez doucement avec un chiffon propre sans frotter." },
      { title: "Rincez la tache", body: "Utilisez de l'eau froide sur l'envers du tissu." },
    ],
    safetyNote: "Vérifiez l'étiquette d'entretien et testez tout produit sur une zone cachée.",
  };

  return {
    title: "Pastrimi i njollës së kafesë",
    summary: "Veproni shpejt dhe trajtojeni njollën para se ta lani rrobën.",
    steps: [
      { title: "Hiqni lëngun e tepërt", body: "Prekeni lehtë me një leckë të pastër dhe mos e fërkoni." },
      { title: "Shpëlajeni njollën", body: "Përdorni ujë të ftohtë nga ana e pasme e pëlhurës." },
    ],
    safetyNote: "Kontrolloni etiketën e kujdesit dhe provojeni produktin në një pjesë të fshehur.",
  };
}

describe("EveryFix multilingual AI", () => {
  beforeEach(() => {
    invokeLLMMock.mockReset();
    listLLMModelsMock.mockReset();
    getGuideCatalogMock.mockReset();
    listLLMModelsMock.mockResolvedValue({ data: [{ id: "claude-haiku-test" }] });
    getGuideCatalogMock.mockResolvedValue({ guides: [], categories: [] });
  });

  it.each([
    {
      language: "Spanish" as const,
      problem: "¿Cómo puedo quitar una mancha de café de una camisa blanca?",
      answer: answerInLanguage("es"),
    },
    {
      language: "Arabic" as const,
      problem: "كيف أزيل بقعة القهوة عن قميص أبيض؟",
      answer: answerInLanguage("ar"),
    },
    {
      language: "French" as const,
      problem: "Comment enlever une tache de café sur une chemise blanche ?",
      answer: answerInLanguage("fr"),
    },
    {
      language: "Albanian" as const,
      problem: "Si mund ta heq njollën e kafesë nga një këmishë e bardhë?",
      answer: answerInLanguage("sq"),
    },
  ])("instructs the model to answer in $language and preserves that script", async ({ language, problem, answer }) => {
    invokeLLMMock.mockResolvedValue({ choices: [{ message: { content: JSON.stringify(answer) } }] });

    const result = await generateEveryFixSolution(problem);

    expect(result.answer).toEqual(answer);
    const messages = invokeLLMMock.mock.calls[0]?.[0]?.messages as Array<{ role: string; content: string }>;
    expect(messages[0]?.content).toContain("LANGUAGE SUPPORT IS REQUIRED");
    expect(messages[0]?.content).toContain("same language and script");
    expect(messages[0]?.content).toContain("Do not infer the user's country");
    for (const language of ["English", "Mandarin Chinese", "Hindi", "Spanish", "Standard Arabic", "French", "Bengali", "Portuguese", "Russian", "Urdu", "Albanian"]) {
      expect(messages[0]?.content).toContain(language);
    }
    expect(messages[1]?.content).toContain(problem);
  });
});
