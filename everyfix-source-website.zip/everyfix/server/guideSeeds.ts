import type { GuideResource, GuideStep } from "../drizzle/schema";

export const seedCategories = [
  { id: "home", name: "Home", description: "Small fixes and safer spaces.", sortOrder: 1 },
  { id: "technology", name: "Technology", description: "Make your devices and accounts work for you.", sortOrder: 2 },
  { id: "money", name: "Money", description: "Clear next steps for money and life admin.", sortOrder: 3 },
  { id: "wellbeing", name: "Health & wellbeing", description: "Gentle, practical ways to look after yourself.", sortOrder: 4 },
  { id: "work", name: "Work", description: "Make the next workday feel more manageable.", sortOrder: 5 },
  { id: "relationships", name: "Relationships", description: "Better conversations, one small step at a time.", sortOrder: 6 },
] as const;

type GuideSeed = {
  id: string;
  categoryId: string;
  title: string;
  summary: string;
  tags: string[];
  minutes: number;
  featured: boolean;
  steps: GuideStep[];
  safetyNote: string | null;
  resources: GuideResource[];
  relatedGuideIds: string[];
};

const redCross = "https://www.redcross.org/get-help/how-to-prepare-for-emergencies/types-of-emergencies/fire.html";
const cisa = "https://www.cisa.gov/topics/cybersecurity-best-practices";
const consumerGov = "https://consumer.gov/your-money/making-budget";
const ftcDebt = "https://consumer.ftc.gov/articles/how-get-out-debt";
const whoStress = "https://www.who.int/publications/i/item/9789240003927";
const nimh = "https://www.nimh.nih.gov/health/topics/caring-for-your-mental-health";
const acas = "https://www.acas.org.uk/talking-to-your-employer-about-a-problem";
const gottman = "https://www.gottman.com/blog/the-four-horsemen-the-antidotes/";

export const seedGuides: GuideSeed[] = [
  {
    id: "make-a-home-fire-plan",
    categoryId: "home",
    title: "Make a simple home fire plan",
    summary: "A working alarm and a practiced way out make a stressful moment easier to act on.",
    tags: ["home", "fire", "smoke alarm", "safety", "emergency", "escape plan"],
    minutes: 4,
    featured: true,
    steps: [
      { title: "Check your alarms", body: "Make sure smoke alarms are installed on each level and near sleeping areas. Test them monthly, and follow the manufacturer's instructions if one does not sound." },
      { title: "Choose two ways out", body: "Walk through each room and identify the main exit and a backup route. Keep doors and windows you might use accessible." },
      { title: "Pick an outdoor meeting spot", body: "Choose one clear place outside where everyone can meet. Make sure everyone, including children and visitors, knows where it is." },
      { title: "Practice the plan", body: "Walk the routes together and agree who can help anyone who may need assistance. Revisit the plan twice a year." },
      { title: "If a fire starts, leave", body: "Get out, stay out, and call your local emergency service from outside. Never go back inside to retrieve belongings." },
    ],
    safetyNote: "A fire can spread quickly. If there is smoke or fire, leave immediately, stay outside, and contact your local emergency service. Do not delay to collect possessions.",
    resources: [{ label: "American Red Cross: Home Fire Safety", url: redCross, description: "Smoke-alarm, escape-plan, and response guidance.", locale: "United States" }],
    relatedGuideIds: ["dripping-tap", "mental-health-next-step"],
  },
  {
    id: "dripping-tap",
    categoryId: "home",
    title: "Deal with a dripping tap calmly",
    summary: "Work out whether this is a quick check or a good time to call a qualified plumber.",
    tags: ["home", "tap", "faucet", "leak", "plumbing", "water"],
    minutes: 5,
    featured: true,
    steps: [
      { title: "Notice when it drips", body: "Check whether the drip continues when the tap is fully off, and whether the water is coming from the spout or around the handle." },
      { title: "Protect the area", body: "Put a bowl or cloth underneath and dry nearby surfaces so you can see whether the leak is spreading." },
      { title: "Check the simple causes", body: "Make sure the handle is fully closed without forcing it. Look for a loose visible part, and check the fixture manual before touching anything." },
      { title: "Stop if the leak is worsening", body: "If you already know where the fixture's shutoff valve is and can operate it safely, turn it off. Otherwise, contact your building manager or a qualified plumber." },
      { title: "Book help for persistent leaks", body: "Share where the water appears, when it started, and whether the leak changes when the tap is used. That helps a professional narrow down the cause." },
    ],
    safetyNote: "Do not force corroded fittings or take apart plumbing you are unfamiliar with. For a fast leak, water near electricity, or damage in a shared building, move clear and contact local qualified help promptly.",
    resources: [{ label: "Find a local qualified plumber", url: "https://www.google.com/search?q=find+a+licensed+plumber+near+me", description: "Search for locally licensed plumbing help; check local credentials and reviews.", locale: "Varies by location" }],
    relatedGuideIds: ["make-a-home-fire-plan", "wifi-keeps-dropping"],
  },
  {
    id: "wifi-keeps-dropping",
    categoryId: "technology",
    title: "Get to the bottom of dropping Wi-Fi",
    summary: "A few quick checks can tell you if the issue is one device, your home setup, or an outage.",
    tags: ["technology", "internet", "wifi", "router", "connection", "slow internet"],
    minutes: 4,
    featured: true,
    steps: [
      { title: "Check the scope", body: "See if the connection drops on more than one device. If only one device is affected, turn its Wi-Fi off and back on, then reconnect." },
      { title: "Look for an outage", body: "Use mobile data to check your internet provider's outage or service-status page before changing router settings." },
      { title: "Restart, don't reset", body: "If there is no outage, restart the modem and router using their normal power instructions. Give them time to reconnect." },
      { title: "Try a closer spot", body: "Move nearer to the router and away from thick walls or other obvious sources of interference. Check whether the connection becomes steadier." },
      { title: "Keep a note for support", body: "Write down when the dropouts happen, which devices are affected, and any lights or error messages. Share that with your provider if it continues." },
    ],
    safetyNote: "Use the router's own restart instructions. Do not press the factory-reset button unless you are ready to set the network up again.",
    resources: [{ label: "CISA: Cybersecurity Best Practices", url: cisa, description: "Advice on keeping connected devices and accounts safer." }],
    relatedGuideIds: ["secure-an-online-account", "dripping-tap"],
  },
  {
    id: "secure-an-online-account",
    categoryId: "technology",
    title: "Secure an account after a suspicious message",
    summary: "If a link or message feels off, pause first; then protect the account without replying to the sender.",
    tags: ["technology", "scam", "phishing", "email", "password", "account security", "privacy"],
    minutes: 5,
    featured: false,
    steps: [
      { title: "Stop interacting with the message", body: "Do not click another link, open an attachment, or share a verification code. Use the service's official app or type its known website address yourself." },
      { title: "Check the account directly", body: "From the official app or website, review recent sign-ins, recovery details, and security alerts." },
      { title: "Change a reused password", body: "If you entered a password, change it on the real service and anywhere else you reused it. Use a unique password and a password manager if available." },
      { title: "Turn on an extra sign-in check", body: "Enable multifactor authentication from the account's security settings, especially for email, banking, and accounts that can reset other passwords." },
      { title: "Contact the real service", body: "Use a contact method listed on the official website. If money, work access, or personal identity information may be at risk, contact the affected provider or your local authority promptly." },
    ],
    safetyNote: "Never share one-time sign-in codes or remote access with someone who contacted you unexpectedly. If money or identity details were disclosed, contact the relevant bank or service using an official number or app.",
    resources: [{ label: "CISA: Cybersecurity Best Practices", url: cisa, description: "Official guidance on strong passwords, updates, cautious clicking, and multifactor authentication.", locale: "United States" }],
    relatedGuideIds: ["wifi-keeps-dropping", "start-a-monthly-budget", "behind-on-bills"],
  },
  {
    id: "start-a-monthly-budget",
    categoryId: "money",
    title: "Start a monthly budget from scratch",
    summary: "Get a clear picture of what comes in and goes out before deciding what to change.",
    tags: ["money", "budget", "bills", "spending", "income", "saving"],
    minutes: 6,
    featured: true,
    steps: [
      { title: "Gather the basics", body: "Collect recent pay information and bills. Include irregular income and bills that do not arrive every month." },
      { title: "List what you spend", body: "Write down essential bills first, then estimate everyday costs such as food, transport, and other spending." },
      { title: "Compare income and expenses", body: "Subtract planned monthly costs from estimated monthly income. If the number is below zero, look for flexible items to adjust and check for bills you may have missed." },
      { title: "Track a little at a time", body: "Record purchases during the month in one place. A simple note or spreadsheet is enough; the goal is to see the pattern." },
      { title: "Review and revise", body: "At month end, compare the plan with what happened. Change the next month's estimates instead of treating a first draft as a failure." },
    ],
    safetyNote: "This is general information, not financial or tax advice. The linked U.S. guide is jurisdiction-specific; assistance programs and consumer protections vary by location.",
    resources: [{ label: "Consumer.gov: Making a Budget", url: consumerGov, description: "A U.S. government step-by-step budgeting guide and worksheet.", locale: "United States" }],
    relatedGuideIds: ["behind-on-bills", "secure-an-online-account", "organize-a-hard-conversation"],
  },
  {
    id: "behind-on-bills",
    categoryId: "money",
    title: "When you are falling behind on bills",
    summary: "Make a short, honest plan and reach out before the situation gets harder to untangle.",
    tags: ["money", "debt", "bills", "late payment", "credit", "budget"],
    minutes: 5,
    featured: false,
    steps: [
      { title: "See the full picture", body: "List each bill, amount due, due date, and any notice you have received. Note which expenses protect immediate essentials such as housing, food, or utilities." },
      { title: "Contact the provider early", body: "Use the contact details on the real bill or official website. Explain what you can afford right now and ask whether a payment plan or hardship option exists." },
      { title: "Write down the agreement", body: "Record the date, person or team, amounts, deadlines, and any reference number. Keep copies of follow-up messages." },
      { title: "Check the terms before agreeing", body: "Make sure you understand fees, interest, dates, and any effect on a service or account. Ask for the terms in writing if they are unclear." },
      { title: "Get impartial local guidance", body: "If the debts are unmanageable, look for a nonprofit or publicly supported advice service in your area. Be cautious of anyone who promises to erase debt for an upfront fee." },
    ],
    safetyNote: "Debt remedies, collection rules, and support programs depend on where you live. Do not share passwords, verification codes, or payment details with an unsolicited caller. Get independent local advice before signing a settlement or loan agreement.",
    resources: [{ label: "FTC: How to Get Out of Debt", url: ftcDebt, description: "U.S. consumer guidance on budgeting, contacting creditors, and avoiding debt-relief scams.", locale: "United States" }],
    relatedGuideIds: ["start-a-monthly-budget", "secure-an-online-account", "organize-a-hard-conversation"],
  },
  {
    id: "reset-a-stressful-day",
    categoryId: "wellbeing",
    title: "Reset after a stressful day",
    summary: "Try a few small grounding steps, then decide whether you need support or a quieter evening.",
    tags: ["wellbeing", "stress", "overwhelmed", "self-care", "calm", "mental health"],
    minutes: 5,
    featured: true,
    steps: [
      { title: "Name what is happening", body: "Pause and put the feeling into a few plain words. You do not need to solve the whole situation in this moment." },
      { title: "Return to the present", body: "Notice a few things you can see, hear, and feel around you, then take a comfortable, unforced breath." },
      { title: "Choose one basic need", body: "Ask whether food, water, fresh air, rest, movement, or a kind conversation would help most right now." },
      { title: "Make the next task smaller", body: "If something still needs doing, write down the smallest useful next step and when you will try it." },
      { title: "Reach out when it stays heavy", body: "If stress is not easing or is getting in the way of daily life, tell someone you trust and consider speaking with a qualified health professional." },
    ],
    safetyNote: "This is general wellbeing information, not mental-health treatment. If you may hurt yourself or someone else, or cannot stay safe, contact local emergency services or a crisis support service in your area now.",
    resources: [{ label: "WHO: Doing What Matters in Times of Stress", url: whoStress, description: "A practical self-help guide from the World Health Organization." }, { label: "NIMH: Caring for Your Mental Health", url: nimh, description: "Mental-health self-care and support information.", locale: "United States" }],
    relatedGuideIds: ["mental-health-next-step", "prepare-for-a-work-conversation", "make-a-home-fire-plan"],
  },
  {
    id: "mental-health-next-step",
    categoryId: "wellbeing",
    title: "Choose a next step when your mood feels stuck",
    summary: "Notice how long the hard patch has lasted and pick a safe, supportive next move.",
    tags: ["wellbeing", "mental health", "low mood", "anxiety", "support", "help"],
    minutes: 5,
    featured: false,
    steps: [
      { title: "Notice the pattern", body: "Write down what has felt difficult, how long it has been going on, and what daily activities it is affecting." },
      { title: "Tell one person you trust", body: "You can keep it simple: say what you have noticed and what kind of support would feel useful today." },
      { title: "Make an appointment if it persists", body: "If the problem is not easing, keeps coming back, or interferes with daily life, consider speaking with a qualified health professional." },
      { title: "Prepare a few notes", body: "Before an appointment, jot down questions, symptoms or changes you have noticed, and any medicine or support you already use." },
      { title: "Find local support", body: "Use a health service or crisis-support directory for your country, or ask a local professional to point you to an appropriate option." },
    ],
    safetyNote: "This guide cannot assess or diagnose symptoms. If you may harm yourself or someone else, or feel unable to stay safe, seek immediate local emergency or crisis support; do not wait for a routine appointment.",
    resources: [{ label: "NIMH: Caring for Your Mental Health", url: nimh, description: "When to seek professional help and basic mental-health self-care information.", locale: "United States" }, { label: "WHO: Mental health", url: "https://www.who.int/news-room/fact-sheets/detail/mental-health-strengthening-our-response", description: "Global context on mental health and access to support." }],
    relatedGuideIds: ["reset-a-stressful-day", "start-a-monthly-budget", "prepare-for-a-work-conversation"],
  },
  {
    id: "organize-a-hard-conversation",
    categoryId: "work",
    title: "Get ready for a difficult conversation at work",
    summary: "A little preparation can keep a tense conversation focused on what needs to change.",
    tags: ["work", "communication", "conflict", "manager", "conversation", "feedback"],
    minutes: 6,
    featured: true,
    steps: [
      { title: "Choose one specific issue", body: "Write down what happened, when it happened, and how it affects the work. Separate things you directly observed from assumptions." },
      { title: "Decide what would help", body: "Pick one realistic request or outcome you want from the conversation." },
      { title: "Choose a calmer time", body: "Ask for a private conversation when there is enough time. Avoid raising sensitive issues in the middle of a heated moment." },
      { title: "Keep the opening factual", body: "Describe the situation and its impact in plain language, then ask how the other person sees it. Listen before agreeing on a next step." },
      { title: "Note what happens next", body: "Summarize any agreed action and date. If the problem continues or feels unsafe, look for an appropriate manager, representative, or local adviser." },
    ],
    safetyNote: "Workplace rights and reporting processes differ by location. If the issue involves threats, harassment, discrimination, or immediate danger, use a safe reporting route and seek qualified local support rather than relying on a private conversation alone.",
    resources: [{ label: "Acas: Talking to your employer about a problem", url: acas, description: "Practical steps for raising a workplace concern.", locale: "United Kingdom" }],
    relatedGuideIds: ["prioritize-a-busy-week", "reset-a-stressful-day", "try-a-repair-conversation"],
  },
  {
    id: "prioritize-a-busy-week",
    categoryId: "work",
    title: "Make a busy week feel more manageable",
    summary: "Turn a crowded task list into one clear priority and a useful conversation about the rest.",
    tags: ["work", "overwhelmed", "priorities", "planning", "time management", "tasks"],
    minutes: 4,
    featured: false,
    steps: [
      { title: "Write every task down", body: "Get tasks out of your head and include their real deadlines, not just the date someone mentioned them." },
      { title: "Mark the true deadlines", body: "Separate must-finish dates from preferred dates. Note any task that blocks someone else." },
      { title: "Choose the next small action", body: "Select one useful task for the next work block and make it small enough to begin." },
      { title: "Ask your manager to rank the rest", body: "If there is more work than time, share the list and ask what should move first and what can wait." },
      { title: "Leave a record", body: "Write down the priorities you agreed and update people who depend on a changed timeline." },
    ],
    safetyNote: "If an unmanageable workload is affecting your health or safety, seek appropriate workplace or professional support. This general guide is not legal or employment advice.",
    resources: [{ label: "Acas: Talking to your employer about a problem", url: acas, description: "A UK resource for raising concerns and agreeing next steps.", locale: "United Kingdom" }],
    relatedGuideIds: ["organize-a-hard-conversation", "reset-a-stressful-day", "try-a-repair-conversation"],
  },
  {
    id: "try-a-repair-conversation",
    categoryId: "relationships",
    title: "Try a calmer repair conversation after an argument",
    summary: "When you are both ready, move from winning the argument to understanding the impact.",
    tags: ["relationships", "argument", "communication", "apology", "conflict", "family"],
    minutes: 5,
    featured: true,
    steps: [
      { title: "Pause until you can speak safely", body: "Take time to settle before returning to the topic. Agree on a time to revisit it rather than forcing an immediate answer." },
      { title: "Describe your own experience", body: "Use a specific moment and explain how it affected you without guessing what the other person intended." },
      { title: "Reflect back what you heard", body: "Try summarizing their point before responding. Ask if you understood it correctly." },
      { title: "Own one part you can change", body: "If you contributed to the hurt, acknowledge the specific action and say what you will try differently." },
      { title: "Agree on one next step", body: "Choose a small change for next time and check in later about whether it helped." },
    ],
    safetyNote: "A repair conversation is not appropriate if you feel threatened, controlled, or unsafe. Focus on your safety and reach a trusted person or local specialist support first.",
    resources: [{ label: "The Gottman Institute: The Four Horsemen and Their Antidotes", url: gottman, description: "Research-informed patterns and ways to keep conversations constructive." }],
    relatedGuideIds: ["make-a-request-without-escalating", "organize-a-hard-conversation", "reset-a-stressful-day"],
  },
  {
    id: "make-a-request-without-escalating",
    categoryId: "relationships",
    title: "Make a difficult request without escalating",
    summary: "Be specific about what would help, and leave room for an honest answer.",
    tags: ["relationships", "communication", "boundaries", "request", "conflict", "family"],
    minutes: 4,
    featured: false,
    steps: [
      { title: "Pick one request", body: "Focus on a concrete action instead of listing every frustration at once." },
      { title: "Name the situation briefly", body: "Describe the specific moment you want to discuss, without using labels or assuming intent." },
      { title: "Say what would help", body: "Ask for a clear and realistic change. For example, name the time or action that would make plans easier." },
      { title: "Listen for their needs too", body: "Give the other person time to respond and clarify what they can agree to." },
      { title: "Set a respectful limit", body: "If you cannot agree, say what you will do next to look after your needs, without making threats." },
    ],
    safetyNote: "Healthy communication is not a substitute for safety planning. If you are afraid of the other person or face coercion or violence, seek confidential local specialist support before raising the issue directly.",
    resources: [{ label: "The Gottman Institute: The Four Horsemen and Their Antidotes", url: gottman, description: "Examples of communication habits that can help conversations stay constructive." }],
    relatedGuideIds: ["try-a-repair-conversation", "organize-a-hard-conversation", "mental-health-next-step"],
  },
];
