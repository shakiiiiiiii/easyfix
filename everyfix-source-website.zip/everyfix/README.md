# EveryFix

EveryFix is an accessible, plain-language hub for useful next steps on everyday problems. It offers searchable, database-backed guides, step-by-step instructions, practical safety notes, trusted further reading, and related solutions. Its dedicated tech-help area provides patient phone and online-safety guidance for older adults and anyone who wants simpler steps. The `/wealth` page is a separate personal-finance and wealth-building education section.

## Stack and data

- React, TypeScript, Wouter, and the Webdev starter UI
- Express and tRPC for guide and AI-solution APIs
- MySQL with Drizzle ORM for categories and guide content
- The server-only built-in Manus AI service for `/ask`
- Managed Manus server and database resources are required for Preview

`drizzle/schema.ts` defines the structured records. `server/guideSeeds.ts` and `server/guideSeedsExpansion.ts` hold the initial examples, including older-adult-friendly technology guides, normal-life solutions, and the Wealth category. `server/seedGuides.ts` adds only missing records so it does not replace edits to existing database rows.

The AI solver retrieves relevant EveryFix guide excerpts when available, then returns structured, general next steps and safety context. Visitors can ask in their preferred language; the solver is instructed to understand multilingual and non-Latin input and answer naturally in the same language. Priority languages are English, Mandarin Chinese, Hindi, Spanish, Standard Arabic, French, Bengali, Portuguese, Russian, and Urdu—the top ten by total speakers, counting both native and second-language speakers—plus Albanian at the user's request. Rankings vary by method, and total-speaker ranking differs from a native-speaker-only ranking [1] [2]. The exact languages it can handle depend on the AI model, so this is broad multilingual support rather than a guarantee for every language or dialect. The website navigation and curated guide library are currently in English. Questions are sent to the server-side AI service to produce a response; EveryFix does not store them as chat history. Visitors are asked to omit identifying or sensitive information. The app does not claim the model browses the web, and it discourages reliance on AI for medical, legal, tax, or individualized financial decisions.

[1]: https://www.ethnologue.com/insights/ethnologue200/ "Ethnologue 200: Total language use includes first- and additional-language speakers"
[2]: https://www.babbel.com/en/magazine/the-10-most-spoken-languages-in-the-world "The 10 Most Spoken Languages in the World in 2026, drawing on Ethnologue data"

## Development

Run the app and API with:

```sh
pnpm dev
```

`PORT` defaults to 3000. The server requires the managed `DATABASE_URL` and Manus AI service environment at runtime.

## Schema and starter content

After a schema change, generate and apply a Drizzle migration:

```sh
pnpm db:push
```

To add new starter guide records without overwriting existing content:

```sh
pnpm db:seed
```

For edits to records already in the database, use an authorized database/content workflow; rerunning the seed will not replace existing values.

## Routes

- `/` — search and browse everyday solutions, including a featured tech-help area
- `/guide/:slug` — one actionable guide, resources, safety notes, related guides, and local bookmarks
- `/ask` — AI-generated general guidance grounded in matching guide excerpts
- `/wealth` — financial education distinct from the everyday problem library

## Validation

```sh
pnpm check
pnpm test
pnpm build
```

Source links identify their geographic scope when appropriate. Financial, employment, food, and crisis-response rules differ across locations, so guide text distinguishes general information from place-specific resources and directs urgent situations to local support.
